#include <stdio.h>
#include <usbstk5515.h>
#include <usbstk5515_interrupts.h>
#include <usbstk5515_spi.h>
#include <usbstk5515_i2c.h>
#include <AIC_func.h>
#include "spi_definitions.h"

Int16 readSPI(void){
	/*reads from SPI 1*/
	//add you code here
}

void writeSPI(Int16 data){
	/*writes to SPI 2*/
	//add you code here
}

void initSPI(void){
	/*enables SPI to use
	1 MHz frequency
	SPI communication mode 1
	Interrupts at the end of every frame
	Frames of 1 character */
	//add you code here
}

void main(void) {
	USBSTK5515_init();

	initSPI();
	Int16 input;
	AIC_init();

	while(1)
	{
		//add you code here
	}
}
