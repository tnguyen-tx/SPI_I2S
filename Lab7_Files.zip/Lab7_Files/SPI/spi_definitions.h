//SPI Definitions
#define SPIENABLE 0x8000;
#define SPICLEN16 0x0078
#define SPI1SELECT 0x1000
#define SPI2SELECT 0x2000

//CMD1 definitions
#define SPIINTERC		0x4000;
#define SPIINTERF		0x8000;

//MODES FOR SPI1
#define SPI1_MODE0 	0x0000;	//ckp is low, active low, output on falling
#define SPI1_MODE1 	0x0400;	//ckp is low, active low, output on rising
#define SPI1_MODE2 	0x0700;	//ckp is high, active high, output on rising
#define SPI1_MODE3 	0x0300;	//ckp is high, active high, output on falling

//MODES FOR SPI2
#define SPI2_MODE0 	0x0000;	//ckp is low, active low, output on falling
#define SPI2_MODE1 	0x0004;	//ckp is low, active low, output on rising
#define SPI2_MODE2 	0x0007;	//ckp is high, active high, output on rising
#define SPI2_MODE3 	0x0003;	//ckp is high, active high, output on falling

//SPI Status definitions
#define SPISTAT1FC 0x02
#define SPISTAT1CC 0x01

//SPI Write definitions
#define SPIWRITECMD 0x0002
#define SPI1_WRITE_CMD	// fill this in for character length 16
#define SPI2_WRITE_CMD	// fill this in for character length 16

//SPI Read definitions
#define SPIREADCMD 0x0001
#define SPI1_READ_CMD 	// fill this in for character length 16
#define SPI2_READ_CMD 	// fill this in for character length 16
