/*
 * main.c
 */
#include <stdio.h>

void Startup(void);
unsigned I2S_receive(unsigned);

void main(void) {
	Startup();
	while(1){
		//Add your code here!
	}
}
