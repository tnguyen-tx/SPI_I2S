#include "C5505.h"

//FILL THESE OUT!
#define I2SENABLE 
#define I2SMONO
#define WORDLENGTH16
#define DSPFORMAT

void InitI2S(void)
{
	I2S2SCTRL = I2SENABLE | I2SMONO | WORDLENGTH16 | DSPFORMAT;
	I2S2INTMASK = 0x0004;
}

unsigned I2S_receive(unsigned value)
{
	/* What Register Goes Here? */ = value;
	while((I2S2INTFL&0x0004)==0);
	return /* What Register Goes Here? */;
}
