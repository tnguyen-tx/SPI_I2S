/*
 * C5515_USB_codec.c
 *
 *  Created on: Oct 7, 2011
 *      Author: Kurt Metzger
 *
 *      To replace C5510 AIC23 support with minimal disruption.
 *      For use with the real time FFT.  Not all code is originally
 *      mine.
 */

#include "usbstk5515.h"
#include "C5505.h"
#include "register_system.h"
#include "sar.h"

void InitSystem(void);
void ConfigPort();
void USBSTK5515_I2C_init(void);
void AIC3204_setup(void);
void InitUART(unsigned int);
void InitSpi(void);
void Init_SAR();
unsigned long int AIC3204_IO(int LeftValue, int RightValue);

int LeftValue, RightValue;
unsigned long volatile SampleCounter;


void Startup()
{
	InitSystem(); 			// init C5515 PLL
	ConfigPort(); 			// configure port use
//    USBSTK5515_I2C_init( ); // Initialize I2C
//	AIC3204_setup();		// initialize CODEC
//	InitUART(5);            // assumes 120 MHz clock, sets 1500k baud
//	InitSpi();				// initialize SPI
	InitI2S();
//	Init_SAR();             // initialize to read push buttons
}

#define PLL_120M 1

void InitSystem(void)
{
    Uint16 i;
// PLL set up from RTC
    // bypass PLL
    CONFIG_MSW = 0x0;

#if (PLL_120M ==1)
    PLL_CNTL2 = 0x8000;
    PLL_CNTL4 = 0x0000;
    PLL_CNTL3 = 0x0806;
    PLL_CNTL1 = 0x8E4B;
#elif (PLL_100M ==1)
    PLL_CNTL2 = 0x8000;
    PLL_CNTL4 = 0x0000;
    PLL_CNTL3 = 0x0806;
    PLL_CNTL1 = 0x8BE8;

#elif (PLL_12M ==1)
    PLL_CNTL2 = 0x8000;
    PLL_CNTL4 = 0x0200;
    PLL_CNTL3 = 0x0806;
    PLL_CNTL1 = 0x82ED;
#elif (PLL_98M ==1)
    // 98.304 MHz
    PLL_CNTL2 = 0x8000;
    PLL_CNTL4 = 0x0000;
    PLL_CNTL3 = 0x0806;
    PLL_CNTL1 = 0x82ED;

#endif

    while ( (PLL_CNTL3 & 0x0008) == 0);
    // Switch to PLL clk
    CONFIG_MSW = 0x1;

// clock gating
// enable all clocks
    IDLE_PCGCR = 0;
    IDLE_PCGCR_MSW = 0xFF84;


// reset peripherals
    PER_RSTCOUNT = 0x02;
    PER_RESET = 0x00fb;
    for (i=0; i< 200; i++);

}

void ConfigPort(void)
{
    //  configure port use by peripheral IO lines
	// 15 14 13 12 11 10 09 08 07 06 05 04 03 02 01 00
	//  0  0  0  1  0  0  0  1  0  0  0  0  0  0  0  0

    EBSR = 0x1100;
}

/*
void get_sample_pair(int *left, int *right)
{
	unsigned long left_right;

	left_right = AIC3204_IO(LeftValue, RightValue);
	*left = left_right >> 16;
	*right = left_right & 0x0000FFFF;
}

void put_sample_pair(int left, int right)
{
	LeftValue = left;
	RightValue = right;
	return;
}
*/
